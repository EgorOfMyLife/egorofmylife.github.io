$(function(){
  var a = $('<a />');
a.attr("src", "./process.pdf" );
$('#keyart-4').append(a);
});